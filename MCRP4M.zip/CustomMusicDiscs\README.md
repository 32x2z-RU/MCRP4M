# Custom Music Discs Resource Pack for Minecraft 1.21.9

## How to Use

### 1. Convert your MP3 files to OGG format
Minecraft requires **OGG Vorbis** format for sounds. You can convert using:
- **Online**: https://convertio.co/mp3-ogg/
- **FFmpeg** (command line): `ffmpeg -i input.mp3 -c:a libvorbis -q:a 4 output.ogg`
- **Audacity**: File → Export → Export as OGG Vorbis

### 2. Name your OGG files exactly as follows:
Place them in: `assets/minecraft/sounds/records/`

| Disc | Filename |
|------|----------|
| 13 | `13.ogg` |
| cat | `cat.ogg` |
| blocks | `blocks.ogg` |
| chirp | `chirp.ogg` |
| far | `far.ogg` |
| mall | `mall.ogg` |
| mellohi | `mellohi.ogg` |
| stal | `stal.ogg` |
| strad | `strad.ogg` |
| ward | `ward.ogg` |
| 11 | `11.ogg` |
| wait | `wait.ogg` |
| pigstep | `pigstep.ogg` |
| otherside | `otherside.ogg` |
| 5 | `5.ogg` |
| relic | `relic.ogg` |
| creator | `creator.ogg` |
| precipice | `precipice.ogg` |

### 3. Install the resource pack
1. Zip the `CustomMusicDiscs` folder (containing `pack.mcmeta` and `assets/`)
2. Place the zip in `%appdata%\.minecraft\resourcepacks\`
3. Enable it in Minecraft: Options → Resource Packs

### 4. Notes
- `"stream": true` in sounds.json means large files are streamed (good for music)
- Recommended bitrate: 128-192 kbps for good quality/size balance
- Maximum file size per disc: ~100MB (Minecraft limit)